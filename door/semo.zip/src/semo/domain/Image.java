package semo.domain;
public class Image {
	
	private String id;
	private String imageType;
	private String imageName;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getImageType() {
		return imageType;
	}
	public void setImageType(String imageType) {
		this.imageType = imageType;
	}
	public String getImgaeName() {
		return imageName;
	}
	public void setImgaeName(String imgaeName) {
		this.imageName = imgaeName;
	}

}
