package semo.store;

public interface exampleMapper {

}
