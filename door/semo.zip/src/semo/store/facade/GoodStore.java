package semo.store.facade;

import java.util.List;

import semo.domain.Good;
import semo.domain.User;

public interface GoodStore {
	
	void insertGood(Good good);//
	void deleteGood(String goodId);//
	List<Good> selectAllGood();//
	List<User> selectWinners(String GoodId);
	
	void insertEnterUsers(String userId, String goodId);
	List<User> selectEnterUsers(String goodId);
	

}
