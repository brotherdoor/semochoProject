package semo.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/checkId.do")
public class IDCheckContoller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		
		PrintWriter out = response.getWriter();
		if(id.equals("123456")){
			out.println("false");
		}else{
			out.println("ok");
		}
	}
		
		
		
		
		
//		UserService service = new UserServiceLogic();
//		String id = request.getParameter("id");
//		User user = service.searchUserById(id);
//		
//		
//		PrintWriter out = response.getWriter();
//		if(id.equals(user.getId())){
//			out.println("false");
//		}else{
//			out.print("ok");
//		}
		
	}












