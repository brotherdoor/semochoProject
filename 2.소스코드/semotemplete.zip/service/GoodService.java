package service;

import java.util.List;

import domain.Good;
import domain.User;

public interface GoodService {
	
	void registerGood(Good good);
	void removeGood(String goodId);
	List<Good> searchAllGood();
	List<User> searchWinners(String goodId);
	void registerEnterUsers(String userId, String goodId);
	List<Good> searchEnterUsers(String goodId);

}
