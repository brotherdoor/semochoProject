package semo.store.mapper;

public interface exampleMapper {

}
