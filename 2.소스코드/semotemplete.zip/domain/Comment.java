package domain;

public class Comment {
	
	String id;
	String content;
	String writerId;

}
