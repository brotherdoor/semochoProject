package domain;

public class User {
	
	String id;
	String password;
	String name;
	String birth;
	String tel;
	String interest;
	String email;
	String gender;
	String grade;
	int semo;

}
