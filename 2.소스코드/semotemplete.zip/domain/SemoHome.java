package domain;

import java.util.List;

public class SemoHome {
	
	String id;
	User user;
	List<Post> posts;
	List<GuestBook> guestBooks;
	List<String> joins;
	List<String> goods;

}
