
package domain;

import java.util.List;

public class Choice {
	
	String id;
	String content;
	Image image;
	List<String> users;

	String id;
	String content;
	Image image;
	List<String> users;

}
