package domain;

public class Image {
	
	String id;
	String imageType;
	String imgaeName;

}
