package domain;

public class GuestBook {
	
	String id;
	String writerId;
	String content;

}
