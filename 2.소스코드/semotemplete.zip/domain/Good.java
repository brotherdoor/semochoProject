package domain;

import java.sql.Date;
import java.util.List;

public class Good {
	
	String id;
	String title;
	String content;
	String product;
	Date startDate;
	Date endDate;
	Image image;
	int useSemo;
	List<String> enterUsers;
	List<String> winners;

}
